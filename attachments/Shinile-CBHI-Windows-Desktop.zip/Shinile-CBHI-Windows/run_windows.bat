@echo off
py -3 app\main.py
if errorlevel 1 pause
