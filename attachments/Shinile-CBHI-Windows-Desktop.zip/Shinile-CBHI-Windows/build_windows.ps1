$ErrorActionPreference='Stop'
py -3 -m pip install --upgrade pip
py -3 -m pip install -r requirements.txt
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --add-data "data\shinile_cbhi_seed.sqlite3;data" --name Shinile-CBHI-Desktop app/main.py
Write-Host "Built dist\\Shinile-CBHI-Desktop.exe"
