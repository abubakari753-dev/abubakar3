# Shinile CBHI Windows Desktop

Offline Windows desktop version sharing the CBHI Excel/CSV registration structure used by the Android project.

## Features
- SQLite local database, no Internet required
- Household/member registration and editing
- Automatic household CBHI ID and member sub-code generation
- Member photos stored locally
- FAN/National Digital ID
- Higher 1930 / Middle 1310 / Lower 720 sliding scale
- Renewed / Un-Renewed status
- Cluster / Sub-PHCU / Kebele management
- Instant offline search
- Excel and CSV import
- Excel and CSV export with user-selected destination
- Database backup/restore
- Designed for 15,000+ households and 30,000+ members

## Windows build
On Windows 10/11 with Python 3.12+:

`powershell -ExecutionPolicy Bypass -File .\build_windows.ps1`

The executable is created at `dist\Shinile-CBHI-Desktop.exe`.

Alternatively upload this project to GitHub. The included GitHub Actions workflow builds the Windows EXE automatically and exposes it as a downloadable artifact.

## Local storage
The application stores its database and photos under `%APPDATA%\ShinileCBHI\`.

This keeps the database separate from the program folder and allows the application to be installed/updated without losing data.
