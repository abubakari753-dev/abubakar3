import os, sys, csv, sqlite3, shutil, threading
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
from openpyxl import load_workbook, Workbook

APP_NAME = 'Shinile CBHI Desktop'
APP_VERSION = '1.0.0'
BASE = Path(os.environ.get('APPDATA', Path.home())) / 'ShinileCBHI'
DB_PATH = BASE / 'shinile_cbhi.sqlite3'
PHOTO_DIR = BASE / 'photos'
EXPORT_DIR = BASE / 'exports'
for p in (BASE, PHOTO_DIR, EXPORT_DIR): p.mkdir(parents=True, exist_ok=True)
SEED_DB = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent)) / 'data' / 'shinile_cbhi_seed.sqlite3'
if not DB_PATH.exists() and SEED_DB.exists():
    shutil.copy2(SEED_DB, DB_PATH)

FIELDS = [
 ('full_name','Full Name'),('dob_day','DOB Day'),('dob_month','DOB Month'),('dob_year','DOB Year'),
 ('gender','Gender'),('household_id','Household CBHI ID'),('member_id','Beneficiary CBHI ID'),
 ('kebele','Kebele'),('gote','Gote'),('relationship','Relationship'),('profession','Profession'),
 ('enroll_day','Enrollment Day'),('enroll_month','Enrollment Month'),('enroll_year','Enrollment Year'),
 ('sliding_scale','Sliding Scale Category'),('rural_town','Rural / Town'),('has_card','Has CBHI ID Card'),
 ('fan','National Digital ID / FAN'),('status','Household Membership Status'),('cluster','Cluster'),
 ('sub_phcu','Sub-PHCU'),('photo_path','Photo Path')]
COLS=[x[0] for x in FIELDS]

LOOKUPS={
 'gender':['Male','Female'],
 'relationship':['Household Head','Husband','Wife','Son','Daughter','Other'],
 'profession':['Farmer','Daily Laborer','Student','Housewife','Government Employee','Private Employee','Other'],
 'sliding_scale':['Higher','Middle','Lower'],
 'rural_town':['Rural','Town'],
 'has_card':['Yes','No'],
 'status':['Renewed','Un-Renewed'],
}

class DB:
 def __init__(self,path=DB_PATH):
  self.path=path; self.con=sqlite3.connect(path); self.con.row_factory=sqlite3.Row; self.init()
 def init(self):
  c=self.con.cursor()
  c.execute('''CREATE TABLE IF NOT EXISTS members (id INTEGER PRIMARY KEY AUTOINCREMENT, %s)''' % ','.join(f'{n} TEXT' for n in COLS))
  c.execute('CREATE INDEX IF NOT EXISTS idx_hh ON members(household_id)')
  c.execute('CREATE INDEX IF NOT EXISTS idx_member ON members(member_id)')
  c.execute('CREATE INDEX IF NOT EXISTS idx_name ON members(full_name)')
  c.execute('CREATE INDEX IF NOT EXISTS idx_kebele ON members(kebele)')
  c.execute('CREATE TABLE IF NOT EXISTS locations (id INTEGER PRIMARY KEY AUTOINCREMENT, cluster TEXT, sub_phcu TEXT, kebele TEXT UNIQUE)')
  self.con.commit()
 def count(self): return self.con.execute('SELECT COUNT(*) FROM members').fetchone()[0]
 def households(self): return self.con.execute("SELECT COUNT(DISTINCT household_id) FROM members WHERE household_id IS NOT NULL AND household_id<>''").fetchone()[0]
 def search(self,q=''):
  q=f'%{q.strip()}%'
  return self.con.execute('SELECT * FROM members WHERE full_name LIKE ? OR household_id LIKE ? OR member_id LIKE ? OR kebele LIKE ? OR gote LIKE ? OR fan LIKE ? ORDER BY household_id, member_id LIMIT 500', (q,q,q,q,q,q)).fetchall()
 def get(self, rid): return self.con.execute('SELECT * FROM members WHERE id=?',(rid,)).fetchone()
 def insert(self,d):
  vals=[d.get(k,'') for k in COLS]; self.con.execute('INSERT INTO members (%s) VALUES (%s)'%(','.join(COLS),','.join('?'*len(COLS))),vals); self.con.commit()
 def update(self,rid,d):
  self.con.execute('UPDATE members SET %s WHERE id=?'%(','.join(f'{k}=?' for k in COLS)),[d.get(k,'') for k in COLS]+[rid]); self.con.commit()
 def delete(self,rid): self.con.execute('DELETE FROM members WHERE id=?',(rid,)); self.con.commit()
 def clear(self): self.con.execute('DELETE FROM members'); self.con.commit()

def norm(v):
 if v is None: return ''
 if isinstance(v,float) and v.is_integer(): return str(int(v))
 return str(v).strip()

def parse_xlsx(path, db, replace=False):
 wb=load_workbook(path,read_only=True,data_only=True)
 ws=wb['CBHI Registration Form'] if 'CBHI Registration Form' in wb.sheetnames else wb[wb.sheetnames[0]]
 # Actual workbook has field labels in row 8 and data from row 11.
 if replace: db.clear()
 inserted=0; current_hh=''
 for row in ws.iter_rows(min_row=11, values_only=True):
  vals=[norm(x) for x in row]
  if not any(vals): continue
  d={k:'' for k in COLS}
  mapping={
   'full_name':0,'dob_day':1,'dob_month':2,'dob_year':3,'gender':4,'household_id':5,'member_id':6,
   'kebele':7,'gote':8,'relationship':9,'profession':10,'enroll_day':11,'enroll_month':12,'enroll_year':13,
   'sliding_scale':14,'rural_town':15,'has_card':16,'fan':17}
  for k,i in mapping.items(): d[k]=vals[i] if i<len(vals) else ''
  if not d['household_id']: d['household_id']=current_hh
  else: current_hh=d['household_id']
  d['status']='Renewed' if d['enroll_day'] or d['enroll_year'] else 'Un-Renewed'
  db.insert(d); inserted+=1
 return inserted

def parse_csv(path, db, replace=False):
 if replace: db.clear()
 with open(path,'r',encoding='utf-8-sig',newline='') as f:
  r=csv.DictReader(f); inserted=0
  aliases={h.lower().strip():h for h in (r.fieldnames or [])}
  for raw in r:
   d={k:'' for k in COLS}
   for k,label in FIELDS:
    for cand in (k,label,label.replace('/',' ')):
     if cand.lower() in aliases: d[k]=norm(raw[aliases[cand.lower()]]); break
   db.insert(d); inserted+=1
 return inserted

def export_xlsx(db,path):
 wb=Workbook(); ws=wb.active; ws.title='CBHI Registration Form'
 headers=[label for _,label in FIELDS]
 ws.append(headers)
 for r in db.con.execute('SELECT %s FROM members ORDER BY household_id, member_id'%','.join(COLS)):
  ws.append([r[k] for k in COLS])
 wb.save(path)

def export_csv(db,path):
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f); w.writerow([label for _,label in FIELDS])
  for r in db.con.execute('SELECT %s FROM members ORDER BY household_id, member_id'%','.join(COLS)): w.writerow([r[k] for k in COLS])

class App(tk.Tk):
 def __init__(self):
  super().__init__(); self.title(f'{APP_NAME} v{APP_VERSION}'); self.geometry('1280x760'); self.minsize(1050,650)
  self.db=DB(); self.selected_id=None; self.photo_img=None
  self.style=ttk.Style(self); self.style.theme_use('clam')
  self.make_ui(); self.refresh(); self.protocol('WM_DELETE_WINDOW', self.destroy)
 def make_ui(self):
  top=ttk.Frame(self,padding=8); top.pack(fill='x')
  ttk.Label(top,text='SHINILE CBHI',font=('Segoe UI',20,'bold')).pack(side='left')
  ttk.Label(top,text='Offline Household & Member Registry',font=('Segoe UI',11)).pack(side='left',padx=15)
  ttk.Button(top,text='Import Excel',command=self.import_excel).pack(side='right',padx=3)
  ttk.Button(top,text='Import CSV',command=self.import_csv).pack(side='right',padx=3)
  ttk.Button(top,text='Export Excel',command=self.export_excel).pack(side='right',padx=3)
  ttk.Button(top,text='Export CSV',command=self.export_csv).pack(side='right',padx=3)
  nb=ttk.Notebook(self); nb.pack(fill='both',expand=True,padx=8,pady=4)
  self.dashboard=ttk.Frame(nb); self.registry=ttk.Frame(nb); self.locations=ttk.Frame(nb); self.settings=ttk.Frame(nb)
  nb.add(self.dashboard,text='Dashboard'); nb.add(self.registry,text='Household / Members'); nb.add(self.locations,text='Kebele / Locations'); nb.add(self.settings,text='Settings')
  self.make_dashboard(); self.make_registry(); self.make_locations(); self.make_settings()
 def make_dashboard(self):
  for w in self.dashboard.winfo_children(): w.destroy()
  cards=ttk.Frame(self.dashboard,padding=20); cards.pack(fill='x')
  self.card_house=ttk.Label(cards,text='0\nHouseholds',font=('Segoe UI',20,'bold'),anchor='center',relief='groove',padding=20); self.card_house.pack(side='left',fill='x',expand=True,padx=8)
  self.card_mem=ttk.Label(cards,text='0\nMembers',font=('Segoe UI',20,'bold'),anchor='center',relief='groove',padding=20); self.card_mem.pack(side='left',fill='x',expand=True,padx=8)
  self.card_renew=ttk.Label(cards,text='0\nRenewed',font=('Segoe UI',20,'bold'),anchor='center',relief='groove',padding=20); self.card_renew.pack(side='left',fill='x',expand=True,padx=8)
  self.card_un=ttk.Label(cards,text='0\nUn-Renewed',font=('Segoe UI',20,'bold'),anchor='center',relief='groove',padding=20); self.card_un.pack(side='left',fill='x',expand=True,padx=8)
  s=ttk.Frame(self.dashboard,padding=20); s.pack(fill='both',expand=True)
  ttk.Label(s,text='Search all records',font=('Segoe UI',12,'bold')).pack(anchor='w')
  q=tk.StringVar(); e=ttk.Entry(s,textvariable=q,font=('Segoe UI',14)); e.pack(fill='x',pady=8); e.bind('<KeyRelease>',lambda x:self.populate_search(q.get()))
  cols=('id','household_id','member_id','full_name','gender','kebele','gote','relationship','sliding_scale','status')
  self.tree=ttk.Treeview(s,columns=cols,show='headings',height=18)
  heads={'id':'ID','household_id':'Household CBHI','member_id':'Member','full_name':'Name','gender':'Gender','kebele':'Kebele','gote':'Gote','relationship':'Relationship','sliding_scale':'Scale','status':'Status'}
  for c in cols:self.tree.heading(c,text=heads[c]); self.tree.column(c,width=100 if c!='full_name' else 210)
  self.tree.pack(fill='both',expand=True); self.tree.bind('<Double-1>',self.open_selected)
  ttk.Label(s,text='Double-click a result to edit the member. Search works fully offline.',foreground='#555').pack(anchor='w',pady=5)
 def make_registry(self):
  left=ttk.Frame(self.registry,padding=10); left.pack(side='left',fill='both',expand=True)
  right=ttk.Frame(self.registry,padding=10,width=300); right.pack(side='right',fill='y')
  self.form={}; grid=ttk.Frame(left); grid.pack(fill='both',expand=True)
  for i,(k,label) in enumerate(FIELDS):
   if k in ('photo_path',): continue
   r=i//2; c=(i%2)*2
   ttk.Label(grid,text=label+':').grid(row=r,column=c,sticky='w',padx=5,pady=4)
   if k in LOOKUPS:
    v=tk.StringVar(); w=ttk.Combobox(grid,textvariable=v,values=LOOKUPS[k],state='readonly',width=30)
   else:
    v=tk.StringVar(); w=ttk.Entry(grid,textvariable=v,width=32)
   self.form[k]=v; w.grid(row=r,column=c+1,sticky='ew',padx=5,pady=4)
  for c in range(4): grid.columnconfigure(c,weight=1)
  btn=ttk.Frame(left); btn.pack(fill='x',pady=10)
  ttk.Button(btn,text='New / Clear',command=self.new_record).pack(side='left',padx=3)
  ttk.Button(btn,text='Auto Code',command=self.auto_codes).pack(side='left',padx=3)
  ttk.Button(btn,text='Save',command=self.save_record).pack(side='left',padx=3)
  ttk.Button(btn,text='Delete',command=self.delete_record).pack(side='left',padx=3)
  ttk.Button(btn,text='Choose Photo',command=self.choose_photo).pack(side='left',padx=3)
  ttk.Button(btn,text='Open Photo Folder',command=lambda:os.startfile(PHOTO_DIR)).pack(side='left',padx=3)
  self.photo_label=ttk.Label(right,text='No photo',anchor='center',relief='groove'); self.photo_label.pack(fill='both',expand=True)
  self.photo_path=ttk.Label(right,text='',wraplength=260); self.photo_path.pack(fill='x',pady=5)
 def make_locations(self):
  f=ttk.Frame(self.locations,padding=15); f.pack(fill='both',expand=True)
  ttk.Label(f,text='Location structure: Cluster → Sub-PHCU → Kebele',font=('Segoe UI',14,'bold')).pack(anchor='w',pady=5)
  row=ttk.Frame(f); row.pack(fill='x',pady=10)
  self.loc_cluster=tk.StringVar(); self.loc_sub=tk.StringVar(); self.loc_kebele=tk.StringVar()
  for txt,var in [('Cluster',self.loc_cluster),('Sub-PHCU',self.loc_sub),('Kebele',self.loc_kebele)]:
   ttk.Label(row,text=txt).pack(side='left',padx=5); ttk.Entry(row,textvariable=var,width=25).pack(side='left',padx=5)
  ttk.Button(row,text='Add / Update Kebele',command=self.save_location).pack(side='left',padx=10)
  self.loc_tree=ttk.Treeview(f,columns=('cluster','sub','kebele'),show='headings');
  for c,h in [('cluster','Cluster'),('sub','Sub-PHCU'),('kebele','Kebele')]: self.loc_tree.heading(c,text=h)
  self.loc_tree.pack(fill='both',expand=True); self.refresh_locations()
 def make_settings(self):
  f=ttk.Frame(self.settings,padding=20); f.pack(fill='both',expand=True)
  ttk.Label(f,text='Local storage',font=('Segoe UI',15,'bold')).pack(anchor='w')
  ttk.Label(f,text=str(BASE)).pack(anchor='w',pady=5)
  ttk.Label(f,text='Database: '+str(DB_PATH)).pack(anchor='w',pady=5)
  ttk.Label(f,text='Photos: '+str(PHOTO_DIR)).pack(anchor='w',pady=5)
  ttk.Label(f,text='Exports: '+str(EXPORT_DIR)).pack(anchor='w',pady=5)
  ttk.Button(f,text='Open Application Data Folder',command=lambda:os.startfile(BASE)).pack(anchor='w',pady=10)
  ttk.Button(f,text='Backup Database',command=self.backup_db).pack(anchor='w',pady=5)
  ttk.Button(f,text='Restore Database',command=self.restore_db).pack(anchor='w',pady=5)
  ttk.Separator(f).pack(fill='x',pady=20)
  ttk.Label(f,text='CBHI payment categories: Higher = 1,930 | Middle = 1,310 | Lower = 720').pack(anchor='w')
  ttk.Label(f,text='Designed for 15,000+ households and 30,000+ member records. All core functions work without Internet.',foreground='#555').pack(anchor='w',pady=5)
 def refresh(self):
  self.card_house.config(text=f'{self.db.households():,}\nHouseholds'); self.card_mem.config(text=f'{self.db.count():,}\nMembers')
  renewed=self.db.con.execute("SELECT COUNT(*) FROM members WHERE status='Renewed'").fetchone()[0]
  unr=self.db.con.execute("SELECT COUNT(*) FROM members WHERE status='Un-Renewed'").fetchone()[0]
  self.card_renew.config(text=f'{renewed:,}\nRenewed')
  self.card_un.config(text=f'{unr:,}\nUn-Renewed')
  self.populate_search('')
 def populate_search(self,q):
  if not hasattr(self,'tree'): return
  for i in self.tree.get_children(): self.tree.delete(i)
  for r in self.db.search(q): self.tree.insert('', 'end', values=[r[c] for c in ('id','household_id','member_id','full_name','gender','kebele','gote','relationship','sliding_scale','status')])
 def open_selected(self,e=None):
  item=self.tree.focus();
  if not item:return
  rid=self.tree.item(item)['values'][0]; r=self.db.get(rid)
  if r:self.load_record(r)
 def load_record(self,r):
  self.selected_id=r['id']
  for k in COLS:
   if k in self.form:self.form[k].set(r[k] or '')
  self.show_photo(r['photo_path'])
 def new_record(self): self.selected_id=None; [v.set('') for v in self.form.values()]; self.photo_label.config(image='',text='No photo'); self.photo_path.config(text='')
 def auto_codes(self):
  if not self.form['household_id'].get():
   existing=self.db.con.execute("SELECT household_id FROM members WHERE household_id LIKE 'P/%' ORDER BY household_id DESC LIMIT 1").fetchone()
   n=1
   if existing:
    try:n=int(existing[0].split('/')[-1])+1
    except:pass
   self.form['household_id'].set(f'P/05/04/09/02/{n:04d}')
  hh=self.form['household_id'].get(); row=self.db.con.execute('SELECT member_id FROM members WHERE household_id=? ORDER BY CAST(member_id AS INTEGER) DESC LIMIT 1',(hh,)).fetchone()
  n=0 if not row else int(row[0] or 0)+1; self.form['member_id'].set(f'{n:02d}')
 def save_record(self):
  d={k:v.get().strip() for k,v in self.form.items()}; d['photo_path']=self.form.get('photo_path',tk.StringVar()).get()
  if not d['full_name'] or not d['household_id'] or not d['member_id']: messagebox.showwarning('Required','Full Name, Household CBHI ID and Member CBHI ID are required.'); return
  if self.selected_id:self.db.update(self.selected_id,d)
  else:self.db.insert(d)
  messagebox.showinfo('Saved','Member registration saved locally.'); self.refresh()
 def delete_record(self):
  if not self.selected_id:return
  if messagebox.askyesno('Delete','Delete this member record?'): self.db.delete(self.selected_id); self.new_record(); self.refresh()
 def choose_photo(self):
  p=filedialog.askopenfilename(title='Select member photo',filetypes=[('Images','*.jpg *.jpeg *.png *.webp'),('All files','*.*')])
  if not p:return
  hh=self.form['household_id'].get() or 'unassigned'; mid=self.form['member_id'].get() or 'member'; ext=Path(p).suffix.lower() or '.jpg'; dest=PHOTO_DIR/f'{hh}_{mid}{ext}'
  shutil.copy2(p,dest); self.show_photo(str(dest)); self.form['photo_path'].set(str(dest))
 def show_photo(self,p):
  self.photo_path.config(text=p or '')
  if p and Path(p).exists():
   try:
    im=Image.open(p); im.thumbnail((280,360)); self.photo_img=ImageTk.PhotoImage(im); self.photo_label.config(image=self.photo_img,text='')
   except:self.photo_label.config(image='',text='Photo unavailable')
  else:self.photo_label.config(image='',text='No photo')
 def import_excel(self):
  p=filedialog.askopenfilename(filetypes=[('Excel workbook','*.xlsx')]);
  if not p:return
  replace=messagebox.askyesno('Import mode','Replace the current local database with this Excel data?\nYes = replace; No = add records.')
  try:n=parse_xlsx(p,self.db,replace); messagebox.showinfo('Import complete',f'{n:,} records imported.'); self.refresh()
  except Exception as e:messagebox.showerror('Import failed',str(e))
 def import_csv(self):
  p=filedialog.askopenfilename(filetypes=[('CSV','*.csv')]);
  if not p:return
  replace=messagebox.askyesno('Import mode','Replace current database?\nYes = replace; No = add records.')
  try:n=parse_csv(p,self.db,replace); messagebox.showinfo('Import complete',f'{n:,} records imported.'); self.refresh()
  except Exception as e:messagebox.showerror('Import failed',str(e))
 def export_excel(self):
  p=filedialog.asksaveasfilename(initialdir=EXPORT_DIR,initialfile=f'Shinile_CBHI_Export_{datetime.now():%Y%m%d_%H%M}.xlsx',defaultextension='.xlsx',filetypes=[('Excel workbook','*.xlsx')]);
  if p:
   try:export_xlsx(self.db,p); messagebox.showinfo('Export complete',f'Saved to:\n{p}')
   except Exception as e:messagebox.showerror('Export failed',str(e))
 def export_csv(self):
  p=filedialog.asksaveasfilename(initialdir=EXPORT_DIR,initialfile=f'Shinile_CBHI_Export_{datetime.now():%Y%m%d_%H%M}.csv',defaultextension='.csv',filetypes=[('CSV','*.csv')]);
  if p:
   try:export_csv(self.db,p); messagebox.showinfo('Export complete',f'Saved to:\n{p}')
   except Exception as e:messagebox.showerror('Export failed',str(e))
 def save_location(self):
  if not self.loc_kebele.get().strip():return
  self.db.con.execute('INSERT OR REPLACE INTO locations(cluster,sub_phcu,kebele) VALUES(?,?,?)',(self.loc_cluster.get(),self.loc_sub.get(),self.loc_kebele.get()));self.db.con.commit();self.refresh_locations()
 def refresh_locations(self):
  if not hasattr(self,'loc_tree'):return
  for i in self.loc_tree.get_children():self.loc_tree.delete(i)
  for r in self.db.con.execute('SELECT cluster,sub_phcu,kebele FROM locations ORDER BY cluster,sub_phcu,kebele'):self.loc_tree.insert('', 'end', values=(r[0],r[1],r[2]))
 def backup_db(self):
  p=filedialog.asksaveasfilename(initialdir=EXPORT_DIR,initialfile=f'Shinile_CBHI_Backup_{datetime.now():%Y%m%d_%H%M}.sqlite3',defaultextension='.sqlite3');
  if p: shutil.copy2(DB_PATH,p); messagebox.showinfo('Backup complete',p)
 def restore_db(self):
  p=filedialog.askopenfilename(filetypes=[('SQLite database','*.sqlite3')]);
  if not p:return
  if messagebox.askyesno('Restore','Replace the current local database?'):
   self.db.con.close(); shutil.copy2(p,DB_PATH); self.db=DB(); self.refresh(); messagebox.showinfo('Restore complete','Database restored.')

if __name__=='__main__': App().mainloop()
